﻿using HMS_API.DB;
using HMS_API.Dtos;
using HMS_API.Interfaces;
using HMS_API.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS_API.Repositories
{
    public class AppointmentRepository : IAppointmentRepository
    {
        private readonly AppDBContext _context;

        public AppointmentRepository(AppDBContext context)
        {
            _context = context;
        }


        public async Task<string> GetDailyReportAsync(DateTime date)
        {
            var appointments = await _context.Appointments.ToListAsync();
            return Appointment.GenerateDailyReport(appointments, date);
        }

        public async Task UpdateAppointmentStatusAsync(int appointmentId, string newStatus)
        {
            var appointment = await _context.Appointments.FindAsync(appointmentId);

            if (appointment == null) throw new Exception("Appointment not found");


            appointment.OnAppointmentStatusChanged += (sender, e) =>
            {
                Console.WriteLine($"🔔 Appointment {e.ProcessedAppointment.EventId} status changed to: {e.ProcessedAppointment.Status}");
            };


            appointment.UpdateStatus(newStatus);

            await _context.SaveChangesAsync();
        }


        public async Task<List<Appointment>> GetAllAsync()
        {
            return await _context.Appointments
                .Include(a => a.Patient).ThenInclude(p => p.AppUser)
                .Include(a => a.Doctor).ThenInclude(p => p.AppUser)
                .Include(a => a.Receptionist).ThenInclude(p => p.AppUser)
                .ToListAsync();
        }

        public async Task<Appointment?> GetByIdAsync(int id)
        {
            return await _context.Appointments
                .Include(a => a.Patient).ThenInclude(p => p.AppUser)
                .Include(a => a.Doctor).ThenInclude(p => p.AppUser)
                .Include(a => a.Receptionist).ThenInclude(p => p.AppUser)
                .FirstOrDefaultAsync(a => a.EventId == id);
        }

        public async Task<Appointment> CreateAsync(Appointment appointment)
        {
            await _context.Appointments.AddAsync(appointment);
            await _context.SaveChangesAsync();
            return appointment;
        }

        public async Task<Appointment?> UpdateAsync(int id, UpdateAppointmentDto appointmentDto)
        {
            var existingAppointment = await _context.Appointments.FirstOrDefaultAsync(a => a.EventId == id);
            if (existingAppointment == null) return null;

            existingAppointment.AppointmentDate = appointmentDto.AppointmentDate;
            existingAppointment.Status = appointmentDto.Status;

            await _context.SaveChangesAsync();
            return await _context.Appointments
                .Include(a => a.Patient).ThenInclude(p => p.AppUser)
                .Include(a => a.Doctor).ThenInclude(p => p.AppUser)
                .Include(a => a.Receptionist).ThenInclude(p => p.AppUser)
                .FirstOrDefaultAsync(a => a.EventId == existingAppointment.EventId);
        }

        public async Task<Appointment?> DeleteAsync(int id)
        {
            var appointment = await _context.Appointments.FirstOrDefaultAsync(a => a.EventId == id);
            if (appointment == null) return null;

            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();
            return appointment;
        }
    }
}
