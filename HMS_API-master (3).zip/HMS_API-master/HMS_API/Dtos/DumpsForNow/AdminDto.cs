﻿namespace HMS_API.Dtos.DumpsForNow
{
    public class AdminDto
    {
        public int PersonId { get; set; }
        public string FullName { get; set; } = "";
        public string ContactNo { get; set; } = "";
    }
}
