﻿namespace HMS_API.Enums
{
    public enum Role
    {
        Admin,
        Doctor,
        Patient,
        Receptionist,
        LabTechnisian,
        Pharmacist
    }
}
