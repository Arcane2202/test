﻿// MedicalRecordController.cs
using AutoMapper;
using HMS_API.Dtos;
using HMS_API.Interfaces;
using HMS_API.Models;
using Microsoft.AspNetCore.Mvc;
using static HMS_API.HelperFunctions.UtilitiesAndExtensions;

namespace HMS_API.Controllers
{
    [Route("api/medicalrecords")]
    [ApiController]
    public class MedicalRecordsController : ControllerBase
    {
        private readonly IMedicalRecordsRepository _medicalRecordRepository;
        private readonly IMapper _mapper;

        public MedicalRecordsController(IMapper mapper, IMedicalRecordsRepository medicalRecordRepository)
        {
            _mapper = mapper;
            _medicalRecordRepository = medicalRecordRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var medicalRecords = await _medicalRecordRepository.GetAllAsync();
            return Ok(_mapper.Map<List<MedicalRecordsDto>>(medicalRecords));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var medicalRecord = await _medicalRecordRepository.GetByIdAsync(id);
            if (medicalRecord == null) return NotFound();

            var medicalRecordDto = _mapper.Map<MedicalRecordsDto>(medicalRecord);

            string formattedRecord = RecordFormatter.Format(medicalRecordDto);

            return Content(formattedRecord, "text/plain");
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateMedicalRecordsDto medicalRecordDto)
        {
            var medicalRecord = _mapper.Map<MedicalRecords>(medicalRecordDto);
            await _medicalRecordRepository.CreateAsync(medicalRecord);
            return CreatedAtAction(nameof(GetById), new { id = medicalRecord.RecordId }, _mapper.Map<MedicalRecordsDto>(medicalRecord));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateMedicalRecordsDto updateDto)
        {
            var updatedRecord = await _medicalRecordRepository.UpdateAsync(id, updateDto);
            if (updatedRecord == null) return NotFound();
            return Ok(_mapper.Map<MedicalRecordsDto>(updatedRecord));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deletedRecord = await _medicalRecordRepository.DeleteAsync(id);
            if (deletedRecord == null) return NotFound();
            return NoContent();
        }
    }
}
