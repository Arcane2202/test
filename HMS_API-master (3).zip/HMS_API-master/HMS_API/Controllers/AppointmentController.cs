﻿using System.Text.RegularExpressions;
using AutoMapper;
using HMS_API.Dtos;
using HMS_API.HelperFunctions;
using HMS_API.HelperFunctions.QueryObjects;
using HMS_API.Interfaces;
using HMS_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static HMS_API.HelperFunctions.UtilitiesAndExtensions;

namespace HMS_API.Controllers
{
    [Route("api/appointments")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly IMapper _mapper;

        public AppointmentController(IMapper mapper, IAppointmentRepository appointmentRepository)
        {
            _mapper = mapper;
            _appointmentRepository = appointmentRepository;
        }

        [HttpGet]
        [Authorize(Policy = "ReceptionistOnly")]
        public async Task<IActionResult> GetAll([FromQuery] AppointmentQueryObject query)
        {
            try
            {
                if (!User.Identity!.IsAuthenticated)
                {
                    return Unauthorized(new { message = "User is not authenticated" });
                }


                var appointments = await _appointmentRepository.GetAllAsync();
                var appointmentsDto = _mapper.Map<List<AppointmentDto>>(appointments);


                if (query.AppointmentDate != null)
                    appointmentsDto = FilterHelper.Filter(appointmentsDto, a => DateOnly.FromDateTime(a.AppointmentDate) == query.AppointmentDate);
                if (query.DoctorName != null)
                    //appointmentsDto = FilterHelper.Filter(appointmentsDto, a => a.DoctorFullname.ToLower().Contains(query.DoctorName.ToLower()));
                    appointmentsDto = FilterHelper.Filter(appointmentsDto, a => Regex.IsMatch(a.DoctorFullname, Regex.Escape(query.DoctorName!), RegexOptions.IgnoreCase));
                if (query.PatientName != null)
                    appointmentsDto = FilterHelper.Filter(appointmentsDto, a => a.PatientFullname.ToLower().Contains(query.PatientName.ToLower()));
                if (query.ReceptionistName != null)
                    appointmentsDto = FilterHelper.Filter(appointmentsDto, a => a.ReceptionistFullname.ToLower().Contains(query.ReceptionistName.ToLower()));
                if (query.Status != null)
                    appointmentsDto = FilterHelper.Filter(appointmentsDto, a => a.Status == query.Status);

                var skipNumber = (query.PageNumber - 1) * query.PageSize;


                return Ok(appointmentsDto.Skip(skipNumber).Take(query.PageSize));
            }
            catch (UnauthorizedAccessException)
            {
                return Forbid();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while processing your request", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var appointment = await _appointmentRepository.GetByIdAsync(id);
            if (appointment == null) return NotFound();
            return Ok(_mapper.Map<AppointmentDto>(appointment));
        }



        [HttpGet("getSummary{id}")]
        public async Task<IActionResult> GetAppointmentSummary(int id)
        {
            var appointment = await _appointmentRepository.GetByIdAsync(id);

            if (appointment == null)
                return NotFound("Appointment not found");

            var appointmentDto = _mapper.Map<AppointmentDto>(appointment);

            string summary = appointmentDto.GetSummary();

            return Content(summary, "text/plain");
        }




        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateAppointmentDto appointmentDto)
        {
            var appointment = _mapper.Map<Appointment>(appointmentDto);
            await _appointmentRepository.CreateAsync(appointment);
            return CreatedAtAction(nameof(GetById), new { id = appointment.EventId }, _mapper.Map<AppointmentDto>(appointment));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateAppointmentDto updateDto)
        {
            var updatedAppointment = await _appointmentRepository.UpdateAsync(id, updateDto);
            if (updatedAppointment == null) return NotFound();
            return Ok(_mapper.Map<AppointmentDto>(updatedAppointment));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deletedAppointment = await _appointmentRepository.DeleteAsync(id);
            if (deletedAppointment == null) return NotFound();
            return NoContent();
        }



        [HttpGet("daily-report/{date}")]
        public async Task<IActionResult> GetDailyReport(DateTime date)
        {
            string report = await _appointmentRepository.GetDailyReportAsync(date);
            return Content(report, "text/plain");
        }

        [HttpPut("update-status/{id}")]
        public async Task<IActionResult> UpdateAppointmentStatus(int id, [FromBody] string newStatus)
        {
            await _appointmentRepository.UpdateAppointmentStatusAsync(id, newStatus);
            return Ok(new { Message = "Appointment Status Updated", Status = newStatus });
        }

    }
}
