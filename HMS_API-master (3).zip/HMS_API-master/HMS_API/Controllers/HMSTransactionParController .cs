﻿using AutoMapper;
using HMS_API.Dtos;
using HMS_API.Interfaces;
using HMS_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace HMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HMSTransactionParController : ControllerBase
    {
        private readonly IHMSTransactionParRepository _transactionRepository;
        private readonly IMapper _mapper;

        public HMSTransactionParController(IMapper mapper, IHMSTransactionParRepository transactionRepository)
        {
            _mapper = mapper;
            _transactionRepository = transactionRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var transactions = await _transactionRepository.GetAllAsync();
            return Ok(_mapper.Map<List<HMSTransactionParDto>>(transactions));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var transaction = await _transactionRepository.GetByIdAsync(id);
            if (transaction == null) return NotFound();
            return Ok(_mapper.Map<HMSTransactionParDto>(transaction));
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateHMSTransactionParDto transactionDto)
        {
            var transaction = _mapper.Map<HMSTransactionPar>(transactionDto);
            await _transactionRepository.CreateAsync(transaction);
            return CreatedAtAction(nameof(GetById), new { id = transaction.TransactionId }, _mapper.Map<HMSTransactionParDto>(transaction));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateHMSTransactionParDto updateDto)
        {
            var updatedTransaction = await _transactionRepository.UpdateAsync(id, updateDto);
            if (updatedTransaction == null) return NotFound();
            return Ok(_mapper.Map<HMSTransactionParDto>(updatedTransaction));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deletedTransaction = await _transactionRepository.DeleteAsync(id);
            if (deletedTransaction == null) return NotFound();
            return NoContent();
        }
    }
}
