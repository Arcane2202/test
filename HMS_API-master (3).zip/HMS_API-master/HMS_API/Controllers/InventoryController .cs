﻿using AutoMapper;
using HMS_API.Dtos;
using HMS_API.Interfaces;
using HMS_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace HMS_API.Controllers
{
    [Route("api/inventory")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryRepository _inventoryRepository;
        private readonly IMapper _mapper;

        public InventoryController(IMapper mapper, IInventoryRepository inventoryRepository)
        {
            _mapper = mapper;
            _inventoryRepository = inventoryRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var inventory = await _inventoryRepository.GetAllAsync();
            return Ok(_mapper.Map<List<InventoryDto>>(inventory));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var inventory = await _inventoryRepository.GetByIdAsync(id);
            if (inventory == null) return NotFound();
            return Ok(_mapper.Map<InventoryDto>(inventory));
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateInventoryDto inventoryDto)
        {
            var inventory = _mapper.Map<Inventory>(inventoryDto);
            await _inventoryRepository.CreateAsync(inventory);
            return CreatedAtAction(nameof(GetById), new { id = inventory.ItemId }, _mapper.Map<InventoryDto>(inventory));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateInventoryDto updateDto)
        {
            var updatedInventory = await _inventoryRepository.UpdateAsync(id, updateDto);
            if (updatedInventory == null) return NotFound();
            return Ok(_mapper.Map<InventoryDto>(updatedInventory));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deletedInventory = await _inventoryRepository.DeleteAsync(id);
            if (deletedInventory == null) return NotFound();
            return NoContent();
        }
    }
}
