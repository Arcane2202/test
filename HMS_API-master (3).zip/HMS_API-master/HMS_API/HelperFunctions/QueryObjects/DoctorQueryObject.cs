﻿namespace HMS_API.HelperFunctions.QueryObjects
{
    public class DoctorQueryObject : generalQueryObjects
    {
        public string? DoctorSpecialization { get; set; } = null;

        public int? DoctorExperience { get; set; } = null;

        public string? DoctortName { get; set; }

    }

}
