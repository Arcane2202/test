﻿namespace HMS_API.HelperFunctions.QueryObjects
{
    public class ReceptionistQueryObject : generalQueryObjects
    {

    }
}
