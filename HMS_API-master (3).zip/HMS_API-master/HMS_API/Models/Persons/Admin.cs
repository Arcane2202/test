﻿using System.ComponentModel.DataAnnotations;

namespace HMS_API.Models
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
    }
}
