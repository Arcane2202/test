﻿using HMS_UI.Interfaces;

namespace HMS_UI.Repositories
{
    class PatientRepository : IPatientRepository
    {

    }
}
