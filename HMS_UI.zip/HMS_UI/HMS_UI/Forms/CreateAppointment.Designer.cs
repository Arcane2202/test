﻿using HMS_UI.CustomControls;

namespace HMS_UI
{
    partial class CreateAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            PatientTextBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            DoctorTextBox = new TextBox();
            label3 = new Label();
            apDdateTimePicker = new DateTimePicker();
            label4 = new Label();
            patientData = new DataGridView();
            doctorData = new DataGridView();
            statusComboBox = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            createButton = new Button();
            bindingSource = new BindingSource(components);
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            nameTextBox = new TextBox();
            emailTextBox = new TextBox();
            phoneTextBox = new TextBox();
            cancelButton = new Button();
            AddPatientBtn = new Button();
            CreateDoctorBtn = new Button();
            PatientPageUp = new RightArrowButton();
            patientPageDown = new LeftArrowButton();
            DoctorPageUp = new RightArrowButton();
            DoctorPageDown = new LeftArrowButton();
            ((System.ComponentModel.ISupportInitialize)patientData).BeginInit();
            ((System.ComponentModel.ISupportInitialize)doctorData).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource).BeginInit();
            SuspendLayout();
            // 
            // PatientTextBox
            // 
            PatientTextBox.BackColor = Color.Thistle;
            PatientTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            PatientTextBox.Location = new Point(95, 109);
            PatientTextBox.Margin = new Padding(3, 4, 3, 4);
            PatientTextBox.Name = "PatientTextBox";
            PatientTextBox.Size = new Size(250, 34);
            PatientTextBox.TabIndex = 0;
            PatientTextBox.TextChanged += PatientTextBox_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label1.Location = new Point(14, 113);
            label1.Name = "label1";
            label1.Size = new Size(75, 28);
            label1.TabIndex = 1;
            label1.Text = "Patient";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label2.Location = new Point(544, 113);
            label2.Name = "label2";
            label2.Size = new Size(73, 28);
            label2.TabIndex = 3;
            label2.Text = "Doctor";
            // 
            // DoctorTextBox
            // 
            DoctorTextBox.BackColor = Color.Bisque;
            DoctorTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            DoctorTextBox.Location = new Point(643, 109);
            DoctorTextBox.Margin = new Padding(3, 4, 3, 4);
            DoctorTextBox.Name = "DoctorTextBox";
            DoctorTextBox.Size = new Size(250, 34);
            DoctorTextBox.TabIndex = 2;
            DoctorTextBox.TextChanged += DoctorTextBox_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(955, 177);
            label3.Name = "label3";
            label3.Size = new Size(54, 28);
            label3.TabIndex = 3;
            label3.Text = "Date";
            // 
            // apDdateTimePicker
            // 
            apDdateTimePicker.CalendarFont = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            apDdateTimePicker.Checked = false;
            apDdateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm";
            apDdateTimePicker.Format = DateTimePickerFormat.Custom;
            apDdateTimePicker.Location = new Point(1013, 176);
            apDdateTimePicker.Margin = new Padding(3, 4, 3, 4);
            apDdateTimePicker.Name = "apDdateTimePicker";
            apDdateTimePicker.ShowCheckBox = true;
            apDdateTimePicker.Size = new Size(228, 27);
            apDdateTimePicker.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label4.Location = new Point(943, 248);
            label4.Name = "label4";
            label4.Size = new Size(67, 28);
            label4.TabIndex = 3;
            label4.Text = "Status";
            // 
            // patientData
            // 
            patientData.AllowUserToAddRows = false;
            patientData.AllowUserToDeleteRows = false;
            patientData.BackgroundColor = Color.PowderBlue;
            patientData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            patientData.Location = new Point(14, 156);
            patientData.Margin = new Padding(3, 4, 3, 4);
            patientData.MultiSelect = false;
            patientData.Name = "patientData";
            patientData.ReadOnly = true;
            patientData.RowHeadersWidth = 51;
            patientData.Size = new Size(331, 461);
            patientData.TabIndex = 5;
            // 
            // doctorData
            // 
            doctorData.AllowUserToAddRows = false;
            doctorData.AllowUserToDeleteRows = false;
            doctorData.BackgroundColor = Color.LightBlue;
            doctorData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            doctorData.Location = new Point(422, 156);
            doctorData.Margin = new Padding(3, 4, 3, 4);
            doctorData.MultiSelect = false;
            doctorData.Name = "doctorData";
            doctorData.ReadOnly = true;
            doctorData.RowHeadersWidth = 51;
            doctorData.Size = new Size(472, 461);
            doctorData.TabIndex = 6;
            // 
            // statusComboBox
            // 
            statusComboBox.BackColor = Color.LightGoldenrodYellow;
            statusComboBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            statusComboBox.FormattingEnabled = true;
            statusComboBox.Location = new Point(1013, 244);
            statusComboBox.Margin = new Padding(3, 4, 3, 4);
            statusComboBox.Name = "statusComboBox";
            statusComboBox.Size = new Size(228, 36);
            statusComboBox.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label5.Location = new Point(915, 347);
            label5.Name = "label5";
            label5.Size = new Size(224, 28);
            label5.TabIndex = 3;
            label5.Text = "Appointment Taken By,";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.LightCyan;
            label6.Font = new Font("Segoe UI Black", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.Location = new Point(14, 33);
            label6.Name = "label6";
            label6.Size = new Size(380, 37);
            label6.TabIndex = 9;
            label6.Text = "Create A New Appointment";
            // 
            // createButton
            // 
            createButton.BackColor = Color.DeepSkyBlue;
            createButton.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            createButton.Location = new Point(1139, 109);
            createButton.Margin = new Padding(3, 4, 3, 4);
            createButton.Name = "createButton";
            createButton.Size = new Size(102, 39);
            createButton.TabIndex = 10;
            createButton.Text = "Create";
            createButton.UseVisualStyleBackColor = false;
            createButton.Click += CreateButton_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label7.Location = new Point(915, 396);
            label7.Name = "label7";
            label7.Size = new Size(71, 28);
            label7.TabIndex = 3;
            label7.Text = "Name:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label8.Location = new Point(915, 452);
            label8.Name = "label8";
            label8.Size = new Size(65, 28);
            label8.TabIndex = 3;
            label8.Text = "Email:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label9.Location = new Point(915, 509);
            label9.Name = "label9";
            label9.Size = new Size(76, 28);
            label9.TabIndex = 3;
            label9.Text = "Phone:";
            // 
            // nameTextBox
            // 
            nameTextBox.BackColor = Color.OldLace;
            nameTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            nameTextBox.Location = new Point(987, 392);
            nameTextBox.Margin = new Padding(3, 4, 3, 4);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.ReadOnly = true;
            nameTextBox.Size = new Size(250, 34);
            nameTextBox.TabIndex = 2;
            // 
            // emailTextBox
            // 
            emailTextBox.BackColor = Color.Beige;
            emailTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            emailTextBox.Location = new Point(987, 452);
            emailTextBox.Margin = new Padding(3, 4, 3, 4);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.ReadOnly = true;
            emailTextBox.Size = new Size(250, 34);
            emailTextBox.TabIndex = 2;
            // 
            // phoneTextBox
            // 
            phoneTextBox.BackColor = Color.Wheat;
            phoneTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            phoneTextBox.Location = new Point(987, 505);
            phoneTextBox.Margin = new Padding(3, 4, 3, 4);
            phoneTextBox.Name = "phoneTextBox";
            phoneTextBox.ReadOnly = true;
            phoneTextBox.Size = new Size(250, 34);
            phoneTextBox.TabIndex = 2;
            // 
            // cancelButton
            // 
            cancelButton.BackColor = Color.PaleTurquoise;
            cancelButton.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            cancelButton.Location = new Point(1013, 109);
            cancelButton.Margin = new Padding(3, 4, 3, 4);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(102, 39);
            cancelButton.TabIndex = 10;
            cancelButton.Text = "Cancel";
            cancelButton.UseVisualStyleBackColor = false;
            cancelButton.Click += CancelButton_Click;
            // 
            // AddPatientBtn
            // 
            AddPatientBtn.BackColor = Color.Turquoise;
            AddPatientBtn.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            AddPatientBtn.Location = new Point(73, 625);
            AddPatientBtn.Margin = new Padding(3, 4, 3, 4);
            AddPatientBtn.Name = "AddPatientBtn";
            AddPatientBtn.Size = new Size(211, 59);
            AddPatientBtn.TabIndex = 10;
            AddPatientBtn.Text = "Add A New Patient";
            AddPatientBtn.UseVisualStyleBackColor = false;
            AddPatientBtn.Click += AddPatientBtn_Click;
            // 
            // CreateDoctorBtn
            // 
            CreateDoctorBtn.BackColor = Color.Aquamarine;
            CreateDoctorBtn.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            CreateDoctorBtn.Location = new Point(495, 625);
            CreateDoctorBtn.Margin = new Padding(3, 4, 3, 4);
            CreateDoctorBtn.Name = "CreateDoctorBtn";
            CreateDoctorBtn.Size = new Size(331, 59);
            CreateDoctorBtn.TabIndex = 10;
            CreateDoctorBtn.Text = "Add A New Doctor";
            CreateDoctorBtn.UseVisualStyleBackColor = false;
            CreateDoctorBtn.Click += CreateDoctorBtn_Click;
            // 
            // PatientPageUp
            // 
            PatientPageUp.ArrowColor = SystemColors.Control;
            PatientPageUp.BackColor = SystemColors.ControlDark;
            PatientPageUp.Font = new Font("Segoe UI", 9F);
            PatientPageUp.Location = new Point(325, 625);
            PatientPageUp.Margin = new Padding(3, 4, 3, 4);
            PatientPageUp.Name = "PatientPageUp";
            PatientPageUp.Size = new Size(21, 27);
            PatientPageUp.TabIndex = 11;
            PatientPageUp.Text = "RightButton";
            PatientPageUp.Click += PatientPageUp_Click;
            // 
            // patientPageDown
            // 
            patientPageDown.ArrowColor = SystemColors.Control;
            patientPageDown.BackColor = SystemColors.ControlDark;
            patientPageDown.Location = new Point(14, 625);
            patientPageDown.Margin = new Padding(3, 4, 3, 4);
            patientPageDown.Name = "patientPageDown";
            patientPageDown.Size = new Size(21, 27);
            patientPageDown.TabIndex = 12;
            patientPageDown.Text = "LeftButton";
            patientPageDown.Click += patientPageDown_Click;
            // 
            // DoctorPageUp
            // 
            DoctorPageUp.ArrowColor = SystemColors.Control;
            DoctorPageUp.BackColor = SystemColors.ControlDark;
            DoctorPageUp.Font = new Font("Segoe UI", 9F);
            DoctorPageUp.Location = new Point(873, 625);
            DoctorPageUp.Margin = new Padding(3, 4, 3, 4);
            DoctorPageUp.Name = "DoctorPageUp";
            DoctorPageUp.Size = new Size(21, 27);
            DoctorPageUp.TabIndex = 11;
            DoctorPageUp.Text = "RightButton";
            DoctorPageUp.Click += DoctorPageUp_Click;
            // 
            // DoctorPageDown
            // 
            DoctorPageDown.ArrowColor = SystemColors.Control;
            DoctorPageDown.BackColor = SystemColors.ControlDark;
            DoctorPageDown.Location = new Point(422, 625);
            DoctorPageDown.Margin = new Padding(3, 4, 3, 4);
            DoctorPageDown.Name = "DoctorPageDown";
            DoctorPageDown.Size = new Size(21, 27);
            DoctorPageDown.TabIndex = 12;
            DoctorPageDown.Text = "LeftButton";
            DoctorPageDown.Click += DoctorPageDown_Click;
            // 
            // CreateAppointment
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(1270, 700);
            Controls.Add(DoctorPageDown);
            Controls.Add(patientPageDown);
            Controls.Add(DoctorPageUp);
            Controls.Add(PatientPageUp);
            Controls.Add(cancelButton);
            Controls.Add(CreateDoctorBtn);
            Controls.Add(AddPatientBtn);
            Controls.Add(createButton);
            Controls.Add(label6);
            Controls.Add(statusComboBox);
            Controls.Add(doctorData);
            Controls.Add(patientData);
            Controls.Add(apDdateTimePicker);
            Controls.Add(label5);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(phoneTextBox);
            Controls.Add(emailTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(DoctorTextBox);
            Controls.Add(label1);
            Controls.Add(PatientTextBox);
            Margin = new Padding(3, 4, 3, 4);
            Name = "CreateAppointment";
            Text = "CreateAppointment";
            Load += CreateAppointment_Load;
            ((System.ComponentModel.ISupportInitialize)patientData).EndInit();
            ((System.ComponentModel.ISupportInitialize)doctorData).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox PatientTextBox;
        private Label label1;
        private Label label2;
        private TextBox DoctorTextBox;
        private Label label3;
        private DateTimePicker apDdateTimePicker;
        private Label label4;
        private DataGridView patientData;
        private DataGridView doctorData;
        private ComboBox statusComboBox;
        private Label label5;
        private Label label6;
        private Button createButton;
        private BindingSource bindingSource;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox nameTextBox;
        private TextBox emailTextBox;
        private TextBox phoneTextBox;
        private Button cancelButton;
        private Button AddPatientBtn;
        private Button CreateDoctorBtn;
        private RightArrowButton PatientPageUp;
        private LeftArrowButton patientPageDown;
        private RightArrowButton DoctorPageUp;
        private LeftArrowButton DoctorPageDown;
    }
}