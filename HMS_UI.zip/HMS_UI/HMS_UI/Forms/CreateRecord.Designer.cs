﻿namespace HMS_UI
{
    partial class CreateRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            LabTestPanel = new Panel();
            BackButton = new Button();
            AddButton = new Button();
            RemarksTextBox = new TextBox();
            DoctorTextBox = new TextBox();
            PlatTextBox = new TextBox();
            HemoTextBox = new TextBox();
            RBCTextBox = new TextBox();
            label11 = new Label();
            WBCTextBox = new TextBox();
            label9 = new Label();
            TestDate = new DateTimePicker();
            label8 = new Label();
            TestComboBox = new ComboBox();
            label7 = new Label();
            label5 = new Label();
            label3 = new Label();
            label10 = new Label();
            label2 = new Label();
            nextButton = new Button();
            label6 = new Label();
            recComboBox = new ComboBox();
            label4 = new Label();
            patientPageDown = new HMS_UI.CustomControls.LeftArrowButton();
            PatientPageUp = new HMS_UI.CustomControls.RightArrowButton();
            AddPatientBtn = new Button();
            patientData = new DataGridView();
            label1 = new Label();
            PatientTextBox = new TextBox();
            panel1.SuspendLayout();
            LabTestPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)patientData).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoSize = true;
            panel1.Controls.Add(LabTestPanel);
            panel1.Controls.Add(nextButton);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(recComboBox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(patientPageDown);
            panel1.Controls.Add(PatientPageUp);
            panel1.Controls.Add(AddPatientBtn);
            panel1.Controls.Add(patientData);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(PatientTextBox);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1009, 720);
            panel1.TabIndex = 0;
            // 
            // LabTestPanel
            // 
            LabTestPanel.Controls.Add(BackButton);
            LabTestPanel.Controls.Add(AddButton);
            LabTestPanel.Controls.Add(RemarksTextBox);
            LabTestPanel.Controls.Add(DoctorTextBox);
            LabTestPanel.Controls.Add(PlatTextBox);
            LabTestPanel.Controls.Add(HemoTextBox);
            LabTestPanel.Controls.Add(RBCTextBox);
            LabTestPanel.Controls.Add(label11);
            LabTestPanel.Controls.Add(WBCTextBox);
            LabTestPanel.Controls.Add(label9);
            LabTestPanel.Controls.Add(TestDate);
            LabTestPanel.Controls.Add(label8);
            LabTestPanel.Controls.Add(TestComboBox);
            LabTestPanel.Controls.Add(label7);
            LabTestPanel.Controls.Add(label5);
            LabTestPanel.Controls.Add(label3);
            LabTestPanel.Controls.Add(label10);
            LabTestPanel.Controls.Add(label2);
            LabTestPanel.Dock = DockStyle.Fill;
            LabTestPanel.Location = new Point(0, 0);
            LabTestPanel.Margin = new Padding(3, 4, 3, 4);
            LabTestPanel.Name = "LabTestPanel";
            LabTestPanel.Size = new Size(1009, 720);
            LabTestPanel.TabIndex = 23;
            // 
            // BackButton
            // 
            BackButton.BackColor = Color.Moccasin;
            BackButton.Font = new Font("Segoe UI Black", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BackButton.Location = new Point(583, 392);
            BackButton.Margin = new Padding(3, 4, 3, 4);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(194, 57);
            BackButton.TabIndex = 4;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // AddButton
            // 
            AddButton.BackColor = Color.MistyRose;
            AddButton.Font = new Font("Segoe UI Black", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            AddButton.Location = new Point(784, 392);
            AddButton.Margin = new Padding(3, 4, 3, 4);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(194, 57);
            AddButton.TabIndex = 4;
            AddButton.Text = "Add";
            AddButton.UseVisualStyleBackColor = false;
            AddButton.Click += AddButton_Click;
            // 
            // RemarksTextBox
            // 
            RemarksTextBox.BackColor = Color.LemonChiffon;
            RemarksTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            RemarksTextBox.Location = new Point(523, 143);
            RemarksTextBox.Margin = new Padding(3, 4, 3, 4);
            RemarksTextBox.Multiline = true;
            RemarksTextBox.Name = "RemarksTextBox";
            RemarksTextBox.Size = new Size(454, 240);
            RemarksTextBox.TabIndex = 3;
            // 
            // DoctorTextBox
            // 
            DoctorTextBox.BackColor = Color.Thistle;
            DoctorTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            DoctorTextBox.Location = new Point(274, 559);
            DoctorTextBox.Margin = new Padding(3, 4, 3, 4);
            DoctorTextBox.Name = "DoctorTextBox";
            DoctorTextBox.Size = new Size(212, 42);
            DoctorTextBox.TabIndex = 3;
            // 
            // PlatTextBox
            // 
            PlatTextBox.BackColor = Color.PaleTurquoise;
            PlatTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            PlatTextBox.Location = new Point(275, 479);
            PlatTextBox.Margin = new Padding(3, 4, 3, 4);
            PlatTextBox.Name = "PlatTextBox";
            PlatTextBox.Size = new Size(211, 42);
            PlatTextBox.TabIndex = 3;
            // 
            // HemoTextBox
            // 
            HemoTextBox.BackColor = Color.LightCyan;
            HemoTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            HemoTextBox.Location = new Point(275, 396);
            HemoTextBox.Margin = new Padding(3, 4, 3, 4);
            HemoTextBox.Name = "HemoTextBox";
            HemoTextBox.Size = new Size(211, 42);
            HemoTextBox.TabIndex = 3;
            // 
            // RBCTextBox
            // 
            RBCTextBox.BackColor = Color.Wheat;
            RBCTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            RBCTextBox.Location = new Point(275, 313);
            RBCTextBox.Margin = new Padding(3, 4, 3, 4);
            RBCTextBox.Name = "RBCTextBox";
            RBCTextBox.Size = new Size(211, 42);
            RBCTextBox.TabIndex = 3;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label11.Location = new Point(102, 571);
            label11.Name = "label11";
            label11.Size = new Size(166, 30);
            label11.TabIndex = 0;
            label11.Text = "Doctor's Name";
            // 
            // WBCTextBox
            // 
            WBCTextBox.BackColor = Color.NavajoWhite;
            WBCTextBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            WBCTextBox.Location = new Point(275, 236);
            WBCTextBox.Margin = new Padding(3, 4, 3, 4);
            WBCTextBox.Name = "WBCTextBox";
            WBCTextBox.Size = new Size(211, 42);
            WBCTextBox.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label9.Location = new Point(102, 491);
            label9.Name = "label9";
            label9.Size = new Size(171, 30);
            label9.TabIndex = 0;
            label9.Text = "Platelets Count";
            // 
            // TestDate
            // 
            TestDate.CalendarFont = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TestDate.Format = DateTimePickerFormat.Short;
            TestDate.Location = new Point(271, 183);
            TestDate.Margin = new Padding(3, 4, 3, 4);
            TestDate.Name = "TestDate";
            TestDate.Size = new Size(215, 27);
            TestDate.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label8.Location = new Point(73, 408);
            label8.Name = "label8";
            label8.Size = new Size(200, 30);
            label8.TabIndex = 0;
            label8.Text = "Hemoglobin Level";
            // 
            // TestComboBox
            // 
            TestComboBox.BackColor = Color.LightPink;
            TestComboBox.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            TestComboBox.FormattingEnabled = true;
            TestComboBox.Location = new Point(273, 108);
            TestComboBox.Margin = new Padding(3, 4, 3, 4);
            TestComboBox.Name = "TestComboBox";
            TestComboBox.Size = new Size(213, 44);
            TestComboBox.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label7.Location = new Point(40, 325);
            label7.Name = "label7";
            label7.Size = new Size(236, 30);
            label7.TabIndex = 0;
            label7.Text = "Red Blood Cells (RBC)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label5.Location = new Point(14, 248);
            label5.Name = "label5";
            label5.Size = new Size(267, 30);
            label5.TabIndex = 0;
            label5.Text = "White Blood Cells (WBC)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label3.Location = new Point(155, 183);
            label3.Name = "label3";
            label3.Size = new Size(110, 30);
            label3.TabIndex = 0;
            label3.Text = "Test Date";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label10.Location = new Point(522, 108);
            label10.Name = "label10";
            label10.Size = new Size(101, 30);
            label10.TabIndex = 0;
            label10.Text = "Remarks";
            label10.Click += label2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold);
            label2.Location = new Point(145, 120);
            label2.Name = "label2";
            label2.Size = new Size(122, 30);
            label2.TabIndex = 0;
            label2.Text = "Test Name";
            label2.Click += label2_Click;
            // 
            // nextButton
            // 
            nextButton.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            nextButton.Location = new Point(767, 357);
            nextButton.Margin = new Padding(3, 4, 3, 4);
            nextButton.Name = "nextButton";
            nextButton.Size = new Size(229, 48);
            nextButton.TabIndex = 22;
            nextButton.Text = "Next";
            nextButton.UseVisualStyleBackColor = true;
            nextButton.Click += nextButton_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.Location = new Point(26, 43);
            label6.Name = "label6";
            label6.Size = new Size(375, 37);
            label6.TabIndex = 21;
            label6.Text = "Add A New Medical Record";
            // 
            // recComboBox
            // 
            recComboBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            recComboBox.FormattingEnabled = true;
            recComboBox.Location = new Point(767, 268);
            recComboBox.Margin = new Padding(3, 4, 3, 4);
            recComboBox.Name = "recComboBox";
            recComboBox.Size = new Size(228, 36);
            recComboBox.TabIndex = 20;
            recComboBox.SelectedIndexChanged += recComboBox_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label4.Location = new Point(643, 272);
            label4.Name = "label4";
            label4.Size = new Size(123, 28);
            label4.TabIndex = 19;
            label4.Text = "Record Type";
            // 
            // patientPageDown
            // 
            patientPageDown.ArrowColor = SystemColors.Control;
            patientPageDown.BackColor = SystemColors.ControlDark;
            patientPageDown.Location = new Point(26, 640);
            patientPageDown.Margin = new Padding(3, 4, 3, 4);
            patientPageDown.Name = "patientPageDown";
            patientPageDown.Size = new Size(21, 43);
            patientPageDown.TabIndex = 18;
            patientPageDown.Text = "LeftButton";
            patientPageDown.Click += patientPageDown_Click;
            // 
            // PatientPageUp
            // 
            PatientPageUp.ArrowColor = SystemColors.Control;
            PatientPageUp.BackColor = SystemColors.ControlDark;
            PatientPageUp.Font = new Font("Segoe UI", 9F);
            PatientPageUp.Location = new Point(592, 640);
            PatientPageUp.Margin = new Padding(3, 4, 3, 4);
            PatientPageUp.Name = "PatientPageUp";
            PatientPageUp.Size = new Size(21, 43);
            PatientPageUp.TabIndex = 17;
            PatientPageUp.Text = "RightButton";
            PatientPageUp.Click += PatientPageUp_Click;
            // 
            // AddPatientBtn
            // 
            AddPatientBtn.Font = new Font("Segoe UI Black", 12.75F, FontStyle.Bold);
            AddPatientBtn.Location = new Point(54, 640);
            AddPatientBtn.Margin = new Padding(3, 4, 3, 4);
            AddPatientBtn.Name = "AddPatientBtn";
            AddPatientBtn.Size = new Size(531, 43);
            AddPatientBtn.TabIndex = 16;
            AddPatientBtn.Text = "Add A New Patient";
            AddPatientBtn.UseVisualStyleBackColor = true;
            AddPatientBtn.Click += AddPatientBtn_Click;
            // 
            // patientData
            // 
            patientData.AllowUserToAddRows = false;
            patientData.AllowUserToDeleteRows = false;
            patientData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            patientData.Location = new Point(26, 171);
            patientData.Margin = new Padding(3, 4, 3, 4);
            patientData.MultiSelect = false;
            patientData.Name = "patientData";
            patientData.ReadOnly = true;
            patientData.RowHeadersWidth = 51;
            patientData.Size = new Size(586, 461);
            patientData.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label1.Location = new Point(26, 124);
            label1.Name = "label1";
            label1.Size = new Size(75, 28);
            label1.TabIndex = 14;
            label1.Text = "Patient";
            // 
            // PatientTextBox
            // 
            PatientTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            PatientTextBox.Location = new Point(103, 124);
            PatientTextBox.Margin = new Padding(3, 4, 3, 4);
            PatientTextBox.Name = "PatientTextBox";
            PatientTextBox.Size = new Size(509, 34);
            PatientTextBox.TabIndex = 13;
            PatientTextBox.TextChanged += PatientTextBox_TextChanged;
            // 
            // CreateRecord
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(1009, 720);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "CreateRecord";
            Text = "CreateRecord";
            Load += AddRecord_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            LabTestPanel.ResumeLayout(false);
            LabTestPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)patientData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private CustomControls.LeftArrowButton patientPageDown;
        private CustomControls.RightArrowButton PatientPageUp;
        private Button AddPatientBtn;
        private DataGridView patientData;
        private Label label1;
        private TextBox PatientTextBox;
        private ComboBox recComboBox;
        private Label label4;
        private Label label6;
        private Button nextButton;
        private Panel LabTestPanel;
        private Label label2;
        private TextBox RBCTextBox;
        private TextBox WBCTextBox;
        private DateTimePicker TestDate;
        private ComboBox TestComboBox;
        private Label label7;
        private Label label5;
        private Label label3;
        private TextBox HemoTextBox;
        private Label label8;
        private TextBox RemarksTextBox;
        private TextBox PlatTextBox;
        private Label label9;
        private Button AddButton;
        private TextBox DoctorTextBox;
        private Label label11;
        private Label label10;
        private Button BackButton;
    }
}