﻿namespace HMS_UI
{
    partial class Doctors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            doctorData = new DataGridView();
            tableLayoutPanel2 = new TableLayoutPanel();
            label2 = new Label();
            label1 = new Label();
            DoctorExpTextBox = new TextBox();
            DoctorNameTextBox = new TextBox();
            AddButton = new Button();
            PageSizeTextBox = new TextBox();
            pageNumberTextBox = new TextBox();
            label4 = new Label();
            tableLayoutPanel3 = new TableLayoutPanel();
            SpecializationComboBox = new ComboBox();
            label3 = new Label();
            panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)doctorData).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(tableLayoutPanel1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(914, 600);
            panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(doctorData, 0, 1);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 28.9863911F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 71.0136F));
            tableLayoutPanel1.Size = new Size(914, 600);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // doctorData
            // 
            doctorData.AllowUserToAddRows = false;
            doctorData.AllowUserToDeleteRows = false;
            doctorData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            doctorData.Dock = DockStyle.Fill;
            doctorData.Location = new Point(3, 177);
            doctorData.Margin = new Padding(3, 4, 3, 4);
            doctorData.MultiSelect = false;
            doctorData.Name = "doctorData";
            doctorData.ReadOnly = true;
            doctorData.RowHeadersWidth = 51;
            doctorData.Size = new Size(908, 419);
            doctorData.TabIndex = 10;
            doctorData.CellClick += doctorData_CellClick;
            doctorData.CellMouseEnter += doctorData_CellMouseEnter;
            doctorData.CellMouseLeave += doctorData_CellMouseLeave;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 9;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.7837F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.7837F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.69053352F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.7837F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.00989711F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.7837F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.69053316F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.7837F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.69053316F));
            tableLayoutPanel2.Controls.Add(label2, 0, 4);
            tableLayoutPanel2.Controls.Add(label1, 0, 3);
            tableLayoutPanel2.Controls.Add(DoctorExpTextBox, 5, 4);
            tableLayoutPanel2.Controls.Add(DoctorNameTextBox, 3, 4);
            tableLayoutPanel2.Controls.Add(AddButton, 7, 3);
            tableLayoutPanel2.Controls.Add(pageNumberTextBox, 1, 3);
            tableLayoutPanel2.Controls.Add(label4, 0, 0);
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 3, 3);
            tableLayoutPanel2.Controls.Add(PageSizeTextBox, 1, 4);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 4);
            tableLayoutPanel2.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 5;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 27.1916466F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 1.67500556F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 16.7500553F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 27.19165F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 27.19165F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 27F));
            tableLayoutPanel2.Size = new Size(908, 165);
            tableLayoutPanel2.TabIndex = 11;
            tableLayoutPanel2.Paint += tableLayoutPanel2_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold | FontStyle.Italic);
            label2.Location = new Point(3, 117);
            label2.Name = "label2";
            label2.Size = new Size(164, 48);
            label2.TabIndex = 16;
            label2.Text = "Page Size";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold | FontStyle.Italic);
            label1.Location = new Point(3, 73);
            label1.Name = "label1";
            label1.Size = new Size(164, 44);
            label1.TabIndex = 13;
            label1.Text = "Page Number";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // DoctorExpTextBox
            // 
            DoctorExpTextBox.BackColor = Color.Lavender;
            DoctorExpTextBox.Dock = DockStyle.Fill;
            DoctorExpTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            DoctorExpTextBox.Location = new Point(537, 121);
            DoctorExpTextBox.Margin = new Padding(3, 4, 3, 4);
            DoctorExpTextBox.Name = "DoctorExpTextBox";
            DoctorExpTextBox.PlaceholderText = "Experience";
            DoctorExpTextBox.Size = new Size(164, 34);
            DoctorExpTextBox.TabIndex = 10;
            DoctorExpTextBox.TextChanged += DoctorExpTextBox_TextChanged;
            // 
            // DoctorNameTextBox
            // 
            DoctorNameTextBox.BackColor = Color.NavajoWhite;
            DoctorNameTextBox.Dock = DockStyle.Fill;
            DoctorNameTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            DoctorNameTextBox.Location = new Point(358, 121);
            DoctorNameTextBox.Margin = new Padding(3, 4, 3, 4);
            DoctorNameTextBox.Name = "DoctorNameTextBox";
            DoctorNameTextBox.PlaceholderText = "Name";
            DoctorNameTextBox.Size = new Size(164, 34);
            DoctorNameTextBox.TabIndex = 10;
            DoctorNameTextBox.TextChanged += DoctorNameTextBox_TextChanged;
            // 
            // AddButton
            // 
            AddButton.AutoSize = true;
            AddButton.BackColor = Color.BlanchedAlmond;
            AddButton.Dock = DockStyle.Fill;
            AddButton.Location = new Point(722, 77);
            AddButton.Margin = new Padding(3, 4, 3, 4);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(164, 36);
            AddButton.TabIndex = 19;
            AddButton.Text = "Add Doctor";
            AddButton.UseVisualStyleBackColor = false;
            AddButton.Click += AddButton_Click;
            // 
            // PageSizeTextBox
            // 
            PageSizeTextBox.BackColor = Color.MistyRose;
            PageSizeTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            PageSizeTextBox.Location = new Point(173, 121);
            PageSizeTextBox.Margin = new Padding(3, 4, 3, 4);
            PageSizeTextBox.Name = "PageSizeTextBox";
            PageSizeTextBox.PlaceholderText = "20";
            PageSizeTextBox.Size = new Size(163, 34);
            PageSizeTextBox.TabIndex = 21;
            PageSizeTextBox.TextChanged += PageSizeTextBox_TextChanged;
            // 
            // pageNumberTextBox
            // 
            pageNumberTextBox.BackColor = Color.Bisque;
            pageNumberTextBox.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            pageNumberTextBox.Location = new Point(173, 77);
            pageNumberTextBox.Margin = new Padding(3, 4, 3, 4);
            pageNumberTextBox.Name = "pageNumberTextBox";
            pageNumberTextBox.PlaceholderText = "1";
            pageNumberTextBox.Size = new Size(163, 34);
            pageNumberTextBox.TabIndex = 21;
            pageNumberTextBox.TextChanged += pageNumberTextBox_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.OldLace;
            tableLayoutPanel2.SetColumnSpan(label4, 8);
            label4.Font = new Font("Palatino Linotype", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(3, 0);
            label4.Name = "label4";
            label4.Size = new Size(274, 44);
            label4.TabIndex = 22;
            label4.Text = "Manage Doctors";
            label4.Click += label4_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel2.SetColumnSpan(tableLayoutPanel3, 3);
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Controls.Add(SpecializationComboBox, 1, 0);
            tableLayoutPanel3.Controls.Add(label3, 0, 0);
            tableLayoutPanel3.Location = new Point(358, 77);
            tableLayoutPanel3.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(343, 36);
            tableLayoutPanel3.TabIndex = 24;
            // 
            // SpecializationComboBox
            // 
            SpecializationComboBox.BackColor = Color.PaleGoldenrod;
            SpecializationComboBox.FormattingEnabled = true;
            SpecializationComboBox.Location = new Point(174, 4);
            SpecializationComboBox.Margin = new Padding(3, 4, 3, 4);
            SpecializationComboBox.Name = "SpecializationComboBox";
            SpecializationComboBox.Size = new Size(163, 28);
            SpecializationComboBox.TabIndex = 20;
            SpecializationComboBox.SelectedIndexChanged += SpecializationComboBox_SelectedIndexChanged;
            SpecializationComboBox.TextChanged += SpecializationComboBox_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Right;
            label3.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(49, 0);
            label3.Name = "label3";
            label3.Size = new Size(119, 36);
            label3.TabIndex = 18;
            label3.Text = "Specialization";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Doctors
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(914, 600);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Doctors";
            Text = "Doctors";
            Load += Doctors_Load;
            panel1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)doctorData).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel1;
        private DataGridView doctorData;
        private TableLayoutPanel tableLayoutPanel2;
        private TextBox DoctorNameTextBox;
        private Label label1;
        private Label label2;
        private TextBox DoctorExpTextBox;
        private Label label3;
        private Button AddButton;
        private ComboBox SpecializationComboBox;
        private TextBox PageSizeTextBox;
        private Label label4;
        private TextBox pageNumberTextBox;
        private TableLayoutPanel tableLayoutPanel3;
    }
}